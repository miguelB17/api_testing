import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
//    (You can place your cursor at the end of the ResponseObject below and then press [Ctrl] + [Space] to auto import)
import org.openqa.selenium.Keys as Keys

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Customer Contacts/CustomerContacts', [('baseUrl') : GlobalVariable.baseUrl]))

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Customer Contacts/CustomerContactId', [('baseUrl') : GlobalVariable.baseUrl]))

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Offices/{office Id}/Customer Orders/CustomerOrders', 
        [('baseUrl') : GlobalVariable.baseUrl]))

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Offices/{office Id}/Customer Orders/{customer Order Id}/CustomerOrderId', 
        [('baseUrl') : GlobalVariable.baseUrl]))

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Offices/{office Id}/Customer Orders/{customer Order Id}/GetCustomerOrderCertificateDocument', 
        [('baseUrl') : GlobalVariable.baseUrl]))

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Offices/{office Id}/Customer Orders/{customer Order Id}/GetCustomerOrderConfirmationDocument', 
        [('baseUrl') : GlobalVariable.baseUrl]))

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Offices/{office Id}/Customer Orders/{customer Order Id}/Certificates', 
        [('baseUrl') : GlobalVariable.baseUrl]))

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Offices/{office Id}/Customer Orders/{customer Order Id}/Customer Order Lines/CustomerOrderLines', 
        [('baseUrl') : GlobalVariable.baseUrl]))

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Offices/{office Id}/Customer Orders/{customer Order Id}/Customer Order Lines/CustomerOrderLineId', 
        [('baseUrl') : GlobalVariable.baseUrl]))

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Customer Contacts/CustomerContactsCount', [('baseUrl') : GlobalVariable.baseUrl]))

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Offices/{office Id}/Customer Orders/CustomerOrderCount', 
        [('baseUrl') : GlobalVariable.baseUrl]))

WS.sendRequestAndVerify(findTestObject('Postman/Companies/{company Id}/Offices/{office Id}/Customer Orders/{customer Order Id}/Customer Order Lines/CustomerOrderLineCount', 
        [('baseUrl') : GlobalVariable.baseUrl]))

